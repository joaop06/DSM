"""
1. Todas as questões deste arquivo referem-se ao grafo representado
   na imagem "grafo.png".

2. Importe a classe Graph neste arquivo e implemente em código o grafo
   mostrado na imagem. Use print() para exibir o grafo.

3. Exclua o vértice cujo valor é "Etelvina". Use print() para exibir o grafo
   após a exclusão.
"""