"""
    Copie neste arquivo o código da classe da lista duplamente encadeada
    e implemente nela um método exiba a lista em ordem inversa
    (do último ao primeiro).
"""