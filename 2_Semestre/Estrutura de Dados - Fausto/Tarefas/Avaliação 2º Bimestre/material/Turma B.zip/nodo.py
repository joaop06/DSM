"""
    1. Observe a classe Nodo listada logo abaixo.

    2. Responda: para qual ou quais estruturas esse nodo pode ser utilizado?

    3. Qual seria o propósito dos atributos a, b e c?

"""

class Node:
    def __init__(self, x):
        self.a = x
        self.b = None
        self.c = None
